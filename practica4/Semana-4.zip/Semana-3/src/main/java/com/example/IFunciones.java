package com.example;

public interface IFunciones {
    void subirVolumen();
    void bajarVolumen();
    String cambiarDeCanal();
}
