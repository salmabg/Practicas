package com.example;

public interface IOperacioneStandar {
    double suma(double a, double b);
    double resta(double a, double b);
    double multiplicacion(double a, double b);
    double division(double a, double b);
}
