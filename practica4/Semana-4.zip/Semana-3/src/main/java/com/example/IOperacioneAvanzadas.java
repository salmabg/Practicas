package com.example;

public interface IOperacioneAvanzadas {
    double sqrt(double a);
    double mod(double a, double b);
}
